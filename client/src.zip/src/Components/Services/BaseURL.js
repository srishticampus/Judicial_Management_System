

export const IMG_BASE_URL = 'http://localhost:4048/';
export const API_BASE_URL = 'http://localhost:4048/judisys_api';

// export const IMG_BASE_URL = 'http://hybrid.srishticampus.in';
// export const API_BASE_URL = 'https://hybrid.srishticampus.in/judisys_api';


